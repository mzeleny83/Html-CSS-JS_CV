<?php
header("Access-Control-Allow-Origin: *"); // Adjust as needed
header("Content-Type: application/json");

$counterFile = 'counter.txt';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $counter = (int)file_get_contents($counterFile);
    $counter++;
    file_put_contents($counterFile, $counter);
    echo json_encode(['counter' => $counter]);
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $counter = (int)file_get_contents($counterFile);
    echo json_encode(['counter' => $counter]);
} else {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['error' => 'Method Not Allowed']);
}
?>
